package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner (System.in);
        System.out.println("Qual a distância total percorrida em km ?");
        int x = scan.nextInt();
        System.out.println("Qual o total de combustível gasto em L ?");
        double y = scan.nextDouble();
        double z = x / y;
        System.out.printf("Consumo médio = %.3f", z);
        
        
    }
}
