package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner(System.in);
        double indice = 1.54;
        System.out.println("Qual o preço de compra ?");
        double precoCompra = scan.nextDouble();
        double precoFinal = indice * precoCompra;
        System.out.println("Preço final = " + precoFinal);
        
      
    }
        
    }


