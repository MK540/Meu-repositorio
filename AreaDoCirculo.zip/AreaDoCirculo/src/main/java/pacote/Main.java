package pacote;
import java.util.Scanner;

public class Main {
    public static void main(String[]args) {
        Scanner scan = new Scanner (System.in);
        System.out.println ("Nosso sistema calcula a área do círculo de acordo com a medida do raio.");
        System.out.println ("Informe o valor do raio: ");
        double raio = scan.nextDouble();
        double pi = 3.14159;
        double area = raio * raio * pi;
        System.out.println ("A área é: " + area);
        System.out.println ("O pi é: " + pi);
    }
    
    
}
