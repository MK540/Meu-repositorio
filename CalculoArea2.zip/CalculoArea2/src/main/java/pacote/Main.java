package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        
        Scanner scan = new Scanner (System.in);
        
        Retangulo retangulo = new Retangulo();
        
        Quadrado quadrado = new Quadrado();
        
        Trapezio trapezio = new Trapezio();
        
        System.out.println("Digite a base do retângulo: ");
        retangulo.base = scan.nextDouble();
        
        System.out.println("Digite a altura do retângulo: ");
        retangulo.altura = scan.nextDouble();
        
        System.out.println("Digite o lado do quadrado: ");
        quadrado.lado = scan.nextDouble();
        
        System.out.println("Digite a base maior do trapézio: ");
        trapezio.baseMaior = scan.nextDouble();
        
        System.out.println("Digite a base menor do trapézio: ");
        trapezio.baseMenor = scan.nextDouble();
        
        System.out.println("Digite a altura do trapézio: ");
        trapezio.altura = scan.nextDouble();
        
        System.out.println("Área do retângulo = " + retangulo.getArea());
        
        System.out.println("Área do quadrado = " + quadrado.getArea());
        
        System.out.println("Área do trapézio = " + trapezio.getArea());
        
        
        
        
    }
    
}
