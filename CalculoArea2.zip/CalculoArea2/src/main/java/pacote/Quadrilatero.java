package pacote;

public class Quadrilatero {
    double altura;
 
}
