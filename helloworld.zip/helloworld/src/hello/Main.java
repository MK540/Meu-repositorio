package hello;

public class Main {
	
	public static void main(String []agr) {
		
		System.out.println("Hello World!");
	}
