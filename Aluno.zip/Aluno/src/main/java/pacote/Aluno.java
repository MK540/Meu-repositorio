package pacote;

public class Aluno {
    public static void main (String[]args) {
        String nome = "Pedro";
        int idade = 16;
        char sexo = 'M';
        double altura = 1.80;
        
        System.out.println(nome);
        System.out.println("Idade: " + idade + " anos");
        System.out.println("Sexo: " + sexo);
        System.out.println("Altura: " + altura + " m");
                
                
                
                
        
    }
    
}
