package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Nosso sistema calcula a média ponderada das notas A, B e C, com pesos de 2, 3 e 5, respectivamente");
        System.out.println("Digite o valor da nota A: ");
        double A = scan.nextDouble();
        System.out.println("Digite o valor da nota B: ");
        double B = scan.nextDouble();
        System.out.println("Digite o valor da nota C: ");
        double C = scan.nextDouble();
        double media = (A * 2 + B * 3 + C * 5)/10;
        System.out.printf("MEDIA = %.1f ", media);
        
    }
}

