package pacote;
import java.util.Scanner;
public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Qual o código da peça 1 ?");
        int cod1 = scan.nextInt();
        System.out.println("Qual o número de peças 1 que você vai levar ?");
        int num1 =  scan.nextInt();
        System.out.println("Qual o valor da peça 1 ?");
        double valor1 = scan.nextDouble();
        System.out.println("Qual o código da peça 2 ?");
        int cod2 = scan.nextInt();
        System.out.println("Qual o número de peças 2 que você vai levar ?");
        int num2 = scan.nextInt();
        System.out.println("Qual o valor da peça 2 ?");
        double valor2 = scan.nextDouble();
        double valorFinal = num1 * valor1 + num2 * valor2;
        System.out.println("Código da peça 1: " + cod1);
        System.out.println("Código da peça 2: " + cod2);
        System.out.printf("Valor a pagar: %.2f%n", valorFinal);
        
    }
}
