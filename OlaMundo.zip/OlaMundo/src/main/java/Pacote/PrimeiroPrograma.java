package Pacote;

public class PrimeiroPrograma {
    public static void main (String[]args) {
        System.out.println ("Olá, mundo !");
    }
    
}
