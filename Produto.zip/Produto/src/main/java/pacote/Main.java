package pacote;

import java.util.Scanner;
        
public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner (System.in);
        System.out.println("Nosso sistema calcula o produto de dois números inteiros A e B");
        System.out.println("Digite o valor de A: ");
        int A = scan.nextInt();
        System.out.println("Digite o valor de B: ");
        int B = scan.nextInt();
        int prod = A * B;
        System.out.println("PROD = " + prod);
        
    }
}
