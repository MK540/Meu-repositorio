function calculaIMC(){
   var peso = document.formulario.peso.value;
   var altura = document.formulario.altura.value;
   var imc = peso/(altura*altura);
   var imc = imc.toFixed(2);
   alert (`Seu IMC é ${imc}.`);
}


