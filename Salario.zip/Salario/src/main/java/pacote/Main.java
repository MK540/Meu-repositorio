package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner (System.in);
        System.out.println("Nosso sistema calcula o valor de salário dos funcionários de nossa empresa.");
        System.out.println("Digite o seu número: ");
        int numero = scan.nextInt();
        System.out.println("Digite a sua quantidade de horas trabalhadas no mês: ");
        int horasTrabalhadas = scan.nextInt();
        System.out.println("Digite o valor que você recebe por hora trabalhada: ");
        double salarioHora = scan.nextDouble();
        double salario = horasTrabalhadas * salarioHora;
        System.out.println("Número = " + numero);
        System.out.printf("Salário = U$ %.2f ", salario);
        
        
    }
}
