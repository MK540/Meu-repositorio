package pacote;

import java.util.Scanner;

public class Main {    
    public static void main (String[]args) {
    Scanner scan = new Scanner(System.in);    
    System.out.println("Nosso sistema lê 4 números inteiros A, B, C e D e calcula a diferença do produto de A e B pelo produto de C e D");
    System.out.println("Digite o valor de A: ");
    int A = scan.nextInt();
    System.out.println("Digite o valor de B: ");
    int B = scan.nextInt();
    System.out.println("Digite o valor de C: ");
    int C = scan.nextInt();
    System.out.println("Digite o valor de D: ");
    int D = scan.nextInt();
    int diferenca = A * B - C * D;
    System.out.println("DIFERENCA = " + diferenca);
    
    
    
    
}
}