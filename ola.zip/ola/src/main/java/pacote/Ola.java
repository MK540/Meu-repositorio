package pacote;

public class Ola {
    public static void main(String[] args) {
        System.out.println("Olá mundo!");
    }
}



