package pacote;

import java.util.Scanner;

public class Sistema {
   
    public static void main(String[]args) {
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Bem vindo ao nosso sistema !");
        
        System.out.println("Informe seu nome: ");
        String nome = scan.nextLine();
        
        System.out.println("Informe sua idade: ");
        int idade = scan.nextInt();
        
        System.out.println("Informe sua altura: ");
        double altura = scan.nextDouble();
        
        System.out.println("Bem vindo, " + nome);
        System.out.println("Sua idade é " + idade + " anos");
        System.out.println("Sua altura é de " + altura + " m");
                
      
       
    }
    
}
