package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Nosso sistema calcula a média aritmética ponderada de duas notas: nota A, com peso 3,5, e nota B, com peso 7,5");
        System.out.println("Digite o valor da nota A: ");
        double A = scan.nextDouble();
        System.out.println("Digite o valor da nota B: ");
        double B = scan.nextDouble();
        double media = (A * 3.5 + B * 7.5)/11;
        System.out.printf("MEDIA = %.5f ", media);
    }
}
