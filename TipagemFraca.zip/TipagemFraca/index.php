<?php
$var = 10;
echo "Agora o tipo de dados é: " . gettype($var);
echo "<br>";
$var = 'Maria';
echo "Agora o tipo de dados é: " . gettype($var);
echo "<br>";
$var = 5.85;
echo "Agora o tipo de dados é: " . gettype($var);