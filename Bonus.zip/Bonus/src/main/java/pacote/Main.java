package pacote;

import java.util.Scanner;

public class Main {
    public static void main (String[]args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Qual o seu nome ?");
        String nome = scan.nextLine();
        System.out.println("Qual o seu salário fixo ?");
        double salarioFixo = scan.nextDouble();
        System.out.println("Quanto você vendeu esse mês ?");
        double vendas = scan.nextDouble();
        double salarioFinal = salarioFixo + 0.15 * vendas;
        System.out.println("Nome = " + nome);
        System.out.println("Salário final = " + salarioFinal);
        
    }
}
