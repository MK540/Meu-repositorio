package pacote;

import java.util.Scanner;

public class Sistema {
    
    public static void main (String[]args) {
        
        Scanner scan = new Scanner (System.in);
        
        System.out.println("Bem vindo ao nosso sistema ! Nosso sistema soma dois números inteiros A e B e dá um resultado X.");
        
        System.out.println("Dê o valor de A:");
        int A = scan.nextInt();
        
        System.out.println("Dê o valor de B:");
        int B = scan.nextInt();
        
        int X = A + B;
        System.out.println("O valor de X é: " + X);
                
        
        
    }
    
}
